public class Sale {
    private String saleId;
    private String medicineId;
    private int quantity;
    private double price;
    private String date;

    public Sale(String saleId, String medicineId, int quantity, double price, String date) {
        this.saleId = saleId;
        this.medicineId = medicineId;
        this.quantity = quantity;
        this.price = price;
        this.date = date;
    }

    public String getSaleId() { return saleId; }
    public String getMedicineId() { return medicineId; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
    public String getDate() { return date; }
    public double getTotal() { return quantity * price; }

    public void displaySale() {
        System.out.println("--------------------------------------------");
        System.out.println("Sale ID     : " + saleId);
        System.out.println("Medicine ID : " + medicineId);
        System.out.println("Quantity    : " + quantity);
        System.out.printf("Price       : Rs. %.2f%n", price);
        System.out.printf("Total       : Rs. %.2f%n", getTotal());
        System.out.println("Date        : " + date);
        System.out.println("--------------------------------------------");
    }

    public String toString() {
        return FileManager.clean(saleId) + "|" + FileManager.clean(medicineId) + "|" +
                quantity + "|" + price + "|" + FileManager.clean(date);
    }
}

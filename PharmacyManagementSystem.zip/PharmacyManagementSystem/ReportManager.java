import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class ReportManager {
    private MedicineManager medicineManager;
    private PurchaseManager purchaseManager;
    private SaleManager saleManager;

    public ReportManager(MedicineManager medicineManager, PurchaseManager purchaseManager, SaleManager saleManager) {
        this.medicineManager = medicineManager;
        this.purchaseManager = purchaseManager;
        this.saleManager = saleManager;
    }

    public void stockReport() {
        System.out.println("\n===== STOCK REPORT =====");
        int totalUnits = 0;
        double stockValue = 0;
        for (Medicine m : medicineManager.getMedicines()) {
            System.out.printf("%-10s %-20s Stock: %-5d Value: Rs. %.2f%n", m.getMedicineId(), m.getMedicineName(), m.getQuantity(), m.getQuantity() * m.getPurchasePrice());
            totalUnits += m.getQuantity();
            stockValue += m.getQuantity() * m.getPurchasePrice();
        }
        System.out.println("--------------------------------------------");
        System.out.println("Total medicine units: " + totalUnits);
        System.out.printf("Total stock value: Rs. %.2f%n", stockValue);
    }

    public void lowStockReport() {
        System.out.println("\n===== LOW STOCK REPORT =====");
        boolean found = false;
        for (Medicine m : medicineManager.getMedicines()) {
            if (m.isLowStock()) { System.out.println(m.getMedicineId() + " | " + m.getMedicineName() + " | Stock: " + m.getQuantity() + " | Reorder: " + m.getReorderLevel()); found = true; }
        }
        if (!found) System.out.println("No low-stock medicines.");
    }

    public void expiryReport() {
        System.out.println("\n===== EXPIRY REPORT =====");
        boolean found = false;
        for (Medicine m : medicineManager.getMedicines()) {
            try {
                long days = ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(m.getExpiryDate()));
                if (days < 0) System.out.println(m.getMedicineName() + " | EXPIRED " + Math.abs(days) + " days ago");
                else if (days <= 30) System.out.println(m.getMedicineName() + " | Expires in " + days + " days | " + m.getExpiryDate());
                found = true;
            } catch (Exception ignored) {}
        }
        if (!found) System.out.println("No expiry records found.");
    }

    public void salesPurchaseReport() {
        System.out.println("\n===== SALES AND PURCHASE REPORT =====");
        System.out.printf("Total purchase amount : Rs. %.2f%n", purchaseManager.getTotalPurchaseAmount());
        System.out.printf("Total sales amount    : Rs. %.2f%n", saleManager.getTotalSalesAmount());
        System.out.printf("Difference             : Rs. %.2f%n", saleManager.getTotalSalesAmount() - purchaseManager.getTotalPurchaseAmount());
        System.out.println("Total purchase records: " + purchaseManager.getPurchases().size());
        System.out.println("Total sales records   : " + saleManager.getSales().size());
    }

    public void categoryReport() {
        System.out.println("\n===== CATEGORY-WISE STOCK =====");
        for (Medicine medicine : medicineManager.getMedicines()) {
            System.out.println(medicine.getCategory() + " -> " + medicine.getMedicineName() + " -> " + medicine.getQuantity());
        }
    }

    public void supplierReport() {
        System.out.println("\n===== SUPPLIER-WISE MEDICINES =====");
        for (Medicine medicine : medicineManager.getMedicines()) {
            System.out.println(medicine.getSupplier() + " -> " + medicine.getMedicineName());
        }
    }

    public void summaryReport() {
        System.out.println("\n============================================");
        System.out.println("       PHARMACY SYSTEM SUMMARY");
        System.out.println("============================================");
        System.out.println("Medicines : " + medicineManager.getMedicines().size());
        System.out.println("Purchases : " + purchaseManager.getPurchases().size());
        System.out.println("Sales     : " + saleManager.getSales().size());
        int low = 0, expired = 0, units = 0;
        for (Medicine m : medicineManager.getMedicines()) {
            units += m.getQuantity();
            if (m.isLowStock()) low++;
            if (m.isExpired()) expired++;
        }
        System.out.println("Stock units: " + units);
        System.out.println("Low stock : " + low);
        System.out.println("Expired   : " + expired);
        System.out.printf("Sales     : Rs. %.2f%n", saleManager.getTotalSalesAmount());
        System.out.printf("Purchases : Rs. %.2f%n", purchaseManager.getTotalPurchaseAmount());
        System.out.println("============================================");
    }
}

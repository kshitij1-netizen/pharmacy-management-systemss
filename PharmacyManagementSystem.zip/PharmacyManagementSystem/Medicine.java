import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class Medicine {
    private String medicineId;
    private String medicineName;
    private String category;
    private String supplier;
    private String batchNumber;
    private double purchasePrice;
    private double sellingPrice;
    private int quantity;
    private String manufacturingDate;
    private String expiryDate;
    private int reorderLevel;

    public Medicine() {}

    public Medicine(String medicineId, String medicineName, String category, String supplier,
                    String batchNumber, double purchasePrice, double sellingPrice, int quantity,
                    String manufacturingDate, String expiryDate, int reorderLevel) {
        this.medicineId = medicineId;
        this.medicineName = medicineName;
        this.category = category;
        this.supplier = supplier;
        this.batchNumber = batchNumber;
        this.purchasePrice = purchasePrice;
        this.sellingPrice = sellingPrice;
        this.quantity = quantity;
        this.manufacturingDate = manufacturingDate;
        this.expiryDate = expiryDate;
        this.reorderLevel = reorderLevel;
    }

    public String getMedicineId() { return medicineId; }
    public String getMedicineName() { return medicineName; }
    public String getCategory() { return category; }
    public String getSupplier() { return supplier; }
    public String getBatchNumber() { return batchNumber; }
    public double getPurchasePrice() { return purchasePrice; }
    public double getSellingPrice() { return sellingPrice; }
    public int getQuantity() { return quantity; }
    public String getManufacturingDate() { return manufacturingDate; }
    public String getExpiryDate() { return expiryDate; }
    public int getReorderLevel() { return reorderLevel; }

    public void setMedicineName(String value) { medicineName = value; }
    public void setCategory(String value) { category = value; }
    public void setSupplier(String value) { supplier = value; }
    public void setBatchNumber(String value) { batchNumber = value; }
    public void setPurchasePrice(double value) { purchasePrice = value; }
    public void setSellingPrice(double value) { sellingPrice = value; }
    public void setQuantity(int value) { quantity = value; }
    public void setManufacturingDate(String value) { manufacturingDate = value; }
    public void setExpiryDate(String value) { expiryDate = value; }
    public void setReorderLevel(int value) { reorderLevel = value; }

    public void addStock(int amount) { if (amount > 0) quantity += amount; }

    public boolean reduceStock(int amount) {
        if (amount <= 0 || amount > quantity) return false;
        quantity -= amount;
        return true;
    }

    public boolean isLowStock() { return quantity <= reorderLevel; }

    public boolean isExpired() {
        try { return LocalDate.parse(expiryDate).isBefore(LocalDate.now()); }
        catch (DateTimeParseException e) { return false; }
    }

    public void displayMedicine() {
        System.out.println("--------------------------------------------");
        System.out.println("Medicine ID        : " + medicineId);
        System.out.println("Medicine Name      : " + medicineName);
        System.out.println("Category           : " + category);
        System.out.println("Supplier           : " + supplier);
        System.out.println("Batch Number       : " + batchNumber);
        System.out.printf("Purchase Price     : Rs. %.2f%n", purchasePrice);
        System.out.printf("Selling Price      : Rs. %.2f%n", sellingPrice);
        System.out.println("Quantity           : " + quantity);
        System.out.println("Manufacturing Date : " + manufacturingDate);
        System.out.println("Expiry Date        : " + expiryDate);
        System.out.println("Reorder Level      : " + reorderLevel);
        System.out.println("Stock Status       : " + (isLowStock() ? "LOW STOCK" : "AVAILABLE"));
        System.out.println("Expiry Status      : " + (isExpired() ? "EXPIRED" : "VALID"));
        System.out.println("--------------------------------------------");
    }

    @Override
    public String toString() {
        return FileManager.clean(medicineId) + "|" + FileManager.clean(medicineName) + "|" +
                FileManager.clean(category) + "|" + FileManager.clean(supplier) + "|" +
                FileManager.clean(batchNumber) + "|" + purchasePrice + "|" + sellingPrice + "|" +
                quantity + "|" + manufacturingDate + "|" + expiryDate + "|" + reorderLevel;
    }
}

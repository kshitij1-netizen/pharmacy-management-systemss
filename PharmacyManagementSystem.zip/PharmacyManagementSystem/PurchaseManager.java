import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class PurchaseManager {
    private ArrayList<Purchase> purchases;
    private Scanner scanner;
    private MedicineManager medicineManager;
    private SupplierManager supplierManager;

    public PurchaseManager(Scanner scanner, MedicineManager medicineManager, SupplierManager supplierManager) {
        this.scanner = scanner;
        this.medicineManager = medicineManager;
        this.supplierManager = supplierManager;
        FileManager.createFiles();
        purchases = FileManager.loadPurchases();
    }

    public ArrayList<Purchase> getPurchases() { return purchases; }

    public void addPurchase() {
        System.out.println("\n===== ADD PURCHASE =====");
        String id = text("Purchase ID: ");
        if (findPurchaseById(id) != null) { System.out.println("Purchase ID already exists."); return; }
        Medicine medicine = medicineManager.findMedicineById(text("Medicine ID: "));
        if (medicine == null) { System.out.println("Medicine not found."); return; }
        String supplierId = text("Supplier ID: ");
        if (supplierManager.findSupplierById(supplierId) == null) { System.out.println("Supplier not found."); return; }
        int quantity = positiveInt("Quantity: ");
        double price = positiveDouble("Purchase Price: ");
        String date = text("Date (YYYY-MM-DD, blank=today): ");
        if (date.isEmpty()) date = LocalDate.now().toString();
        Purchase purchase = new Purchase(id, medicine.getMedicineId(), supplierId, quantity, price, date);
        purchases.add(purchase);
        medicine.addStock(quantity);
        FileManager.savePurchases(purchases);
        FileManager.saveMedicines(medicineManager.getMedicines());
        System.out.println("Purchase saved and stock updated.");
    }

    public void viewPurchases() {
        System.out.println("\n===== PURCHASE LIST =====");
        if (purchases.isEmpty()) { System.out.println("No purchases found."); return; }
        for (Purchase p : purchases) p.displayPurchase();
    }

    public void purchaseHistory() {
        viewPurchases();
        System.out.printf("Total Purchase Amount: Rs. %.2f%n", getTotalPurchaseAmount());
    }

    public void searchPurchase() {
        String key = text("Enter purchase ID or medicine ID: ").toLowerCase();
        boolean found = false;
        for (Purchase p : purchases) if (p.getPurchaseId().toLowerCase().contains(key) || p.getMedicineId().toLowerCase().contains(key)) { p.displayPurchase(); found = true; }
        if (!found) System.out.println("Purchase not found.");
    }

    public double getTotalPurchaseAmount() {
        double total = 0;
        for (Purchase p : purchases) total += p.getTotal();
        return total;
    }

    public Purchase findPurchaseById(String id) {
        for (Purchase p : purchases) if (p.getPurchaseId().equalsIgnoreCase(id)) return p;
        return null;
    }

    private String text(String prompt) { System.out.print(prompt); return scanner.nextLine().trim(); }
    private int positiveInt(String prompt) { while (true) { try { int n = Integer.parseInt(text(prompt)); if (n > 0) return n; } catch (Exception ignored) {} System.out.println("Enter a positive integer."); } }
    private double positiveDouble(String prompt) { while (true) { try { double n = Double.parseDouble(text(prompt)); if (n > 0) return n; } catch (Exception ignored) {} System.out.println("Enter a positive amount."); } }
}

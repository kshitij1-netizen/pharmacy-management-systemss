import java.util.ArrayList;
import java.util.Scanner;

public class CategoryManager {
    private ArrayList<Category> categories;
    private Scanner scanner;

    public CategoryManager(Scanner scanner) {
        this.scanner = scanner;
        FileManager.createFiles();
        categories = FileManager.loadCategories();
    }

    public ArrayList<Category> getCategories() { return categories; }

    public void addCategory() {
        System.out.println("\n===== ADD CATEGORY =====");
        String id = text("Category ID: ");
        if (findCategoryById(id) != null) { System.out.println("ID already exists."); return; }
        String name = text("Category Name: ");
        String description = text("Description: ");
        categories.add(new Category(id, name, description));
        FileManager.saveCategories(categories);
        System.out.println("Category added successfully.");
    }

    public void viewCategories() {
        System.out.println("\n===== CATEGORIES =====");
        if (categories.isEmpty()) { System.out.println("No categories found."); return; }
        for (Category c : categories) c.displayCategory();
    }

    public void searchCategoryById() {
        Category c = findCategoryById(text("Category ID: "));
        if (c == null) System.out.println("Category not found."); else c.displayCategory();
    }

    public void searchCategoryByName() {
        String key = text("Category name: ").toLowerCase();
        boolean found = false;
        for (Category c : categories) if (c.getCategoryName().toLowerCase().contains(key)) { c.displayCategory(); found = true; }
        if (!found) System.out.println("Category not found.");
    }

    public void updateCategory() {
        Category c = findCategoryById(text("Category ID: "));
        if (c == null) { System.out.println("Category not found."); return; }
        System.out.print("New name: "); String name = scanner.nextLine().trim();
        System.out.print("New description: "); String description = scanner.nextLine().trim();
        if (!name.isEmpty()) c.setCategoryName(name);
        if (!description.isEmpty()) c.setDescription(description);
        FileManager.saveCategories(categories);
        System.out.println("Category updated.");
    }

    public void deleteCategory() {
        Category c = findCategoryById(text("Category ID: "));
        if (c == null) { System.out.println("Category not found."); return; }
        if (text("Type YES to delete: ").equalsIgnoreCase("YES")) { categories.remove(c); FileManager.saveCategories(categories); System.out.println("Category deleted."); }
        else System.out.println("Delete cancelled.");
    }

    public Category findCategoryById(String id) {
        for (Category c : categories) if (c.getCategoryId().equalsIgnoreCase(id)) return c;
        return null;
    }

    private String text(String prompt) { System.out.print(prompt); return scanner.nextLine().trim(); }
}

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class MedicineManager {
    private ArrayList<Medicine> medicines;
    private Scanner scanner;

    public MedicineManager(Scanner scanner) {
        this.scanner = scanner;
        FileManager.createFiles();
        medicines = FileManager.loadMedicines();
    }

    public ArrayList<Medicine> getMedicines() { return medicines; }

    public void addMedicine() {
        System.out.println("\n===== ADD MEDICINE =====");
        String id = readText("Medicine ID: ");
        if (findMedicineById(id) != null) { System.out.println("ID already exists."); return; }
        String name = readText("Medicine Name: ");
        String category = readText("Category: ");
        String supplier = readText("Supplier ID: ");
        String batch = readText("Batch Number: ");
        double purchase = readPositiveDouble("Purchase Price: ");
        double selling = readPositiveDouble("Selling Price: ");
        int quantity = readNonNegativeInt("Quantity: ");
        String manufacturing = readDate("Manufacturing Date (YYYY-MM-DD): ");
        String expiry = readDate("Expiry Date (YYYY-MM-DD): ");
        if (!LocalDate.parse(expiry).isAfter(LocalDate.parse(manufacturing))) {
            System.out.println("Expiry date must be after manufacturing date.");
            return;
        }
        int reorder = readNonNegativeInt("Reorder Level: ");
        medicines.add(new Medicine(id, name, category, supplier, batch, purchase, selling,
                quantity, manufacturing, expiry, reorder));
        FileManager.saveMedicines(medicines);
        System.out.println("Medicine added successfully.");
    }

    public void viewMedicines() {
        System.out.println("\n===== ALL MEDICINES =====");
        if (medicines.isEmpty()) { System.out.println("No medicines found."); return; }
        for (Medicine medicine : medicines) medicine.displayMedicine();
    }

    public void searchById() {
        Medicine m = findMedicineById(readText("Enter Medicine ID: "));
        if (m == null) System.out.println("Medicine not found."); else m.displayMedicine();
    }

    public void searchByName() {
        String key = readText("Enter medicine name: ").toLowerCase();
        boolean found = false;
        for (Medicine m : medicines) {
            if (m.getMedicineName().toLowerCase().contains(key)) { m.displayMedicine(); found = true; }
        }
        if (!found) System.out.println("Medicine not found.");
    }

    public void searchByCategory() {
        String key = readText("Enter category: ").toLowerCase();
        boolean found = false;
        for (Medicine m : medicines) {
            if (m.getCategory().toLowerCase().contains(key)) { m.displayMedicine(); found = true; }
        }
        if (!found) System.out.println("Medicine not found.");
    }

    public void updateMedicine() {
        Medicine m = findMedicineById(readText("Enter Medicine ID to update: "));
        if (m == null) { System.out.println("Medicine not found."); return; }
        System.out.println("Press ENTER to keep an existing text value.");
        String value;
        value = optionalText("New Name (" + m.getMedicineName() + "): "); if (!value.isEmpty()) m.setMedicineName(value);
        value = optionalText("New Category (" + m.getCategory() + "): "); if (!value.isEmpty()) m.setCategory(value);
        value = optionalText("New Supplier (" + m.getSupplier() + "): "); if (!value.isEmpty()) m.setSupplier(value);
        value = optionalText("New Batch (" + m.getBatchNumber() + "): "); if (!value.isEmpty()) m.setBatchNumber(value);
        String p = optionalText("New Purchase Price (" + m.getPurchasePrice() + "): "); if (!p.isEmpty()) m.setPurchasePrice(parseDouble(p, m.getPurchasePrice()));
        String s = optionalText("New Selling Price (" + m.getSellingPrice() + "): "); if (!s.isEmpty()) m.setSellingPrice(parseDouble(s, m.getSellingPrice()));
        String q = optionalText("New Quantity (" + m.getQuantity() + "): "); if (!q.isEmpty()) m.setQuantity(parseInt(q, m.getQuantity()));
        String e = optionalText("New Expiry (" + m.getExpiryDate() + "): "); if (!e.isEmpty() && validDate(e)) m.setExpiryDate(e);
        String r = optionalText("New Reorder Level (" + m.getReorderLevel() + "): "); if (!r.isEmpty()) m.setReorderLevel(parseInt(r, m.getReorderLevel()));
        FileManager.saveMedicines(medicines);
        System.out.println("Medicine updated successfully.");
    }

    public void deleteMedicine() {
        Medicine m = findMedicineById(readText("Enter Medicine ID to delete: "));
        if (m == null) { System.out.println("Medicine not found."); return; }
        String confirm = readText("Type YES to confirm: ");
        if (confirm.equalsIgnoreCase("YES")) { medicines.remove(m); FileManager.saveMedicines(medicines); System.out.println("Medicine deleted."); }
        else System.out.println("Delete cancelled.");
    }

    public void addStock() {
        Medicine m = findMedicineById(readText("Medicine ID: "));
        if (m == null) { System.out.println("Medicine not found."); return; }
        int amount = readPositiveInt("Quantity to add: ");
        m.addStock(amount); FileManager.saveMedicines(medicines);
        System.out.println("Stock added. New stock: " + m.getQuantity());
    }

    public void reduceStock() {
        Medicine m = findMedicineById(readText("Medicine ID: "));
        if (m == null) { System.out.println("Medicine not found."); return; }
        int amount = readPositiveInt("Quantity to reduce: ");
        if (m.reduceStock(amount)) { FileManager.saveMedicines(medicines); System.out.println("Stock reduced. Remaining: " + m.getQuantity()); }
        else System.out.println("Insufficient stock or invalid quantity.");
    }

    public void showLowStock() {
        boolean found = false;
        System.out.println("\n===== LOW STOCK =====");
        for (Medicine m : medicines) if (m.isLowStock()) { System.out.println(m.getMedicineId() + " | " + m.getMedicineName() + " | " + m.getQuantity()); found = true; }
        if (!found) System.out.println("No low-stock medicines.");
    }

    public void showExpiryDates() {
        System.out.println("\n===== EXPIRY DATES =====");
        if (medicines.isEmpty()) { System.out.println("No medicines found."); return; }
        for (Medicine m : medicines) System.out.println(m.getMedicineId() + " | " + m.getMedicineName() + " | Expiry: " + m.getExpiryDate() + (m.isExpired() ? " | EXPIRED" : ""));
    }

    public void showExpiredMedicines() {
        boolean found = false;
        System.out.println("\n===== EXPIRED MEDICINES =====");
        for (Medicine m : medicines) if (m.isExpired()) { m.displayMedicine(); found = true; }
        if (!found) System.out.println("No expired medicines.");
    }

    public Medicine findMedicineById(String id) {
        for (Medicine m : medicines) if (m.getMedicineId().equalsIgnoreCase(id)) return m;
        return null;
    }

    private String readText(String prompt) { System.out.print(prompt); return scanner.nextLine().trim(); }
    private String optionalText(String prompt) { System.out.print(prompt); return scanner.nextLine().trim(); }
    private int readPositiveInt(String prompt) { while (true) { int n = readInt(prompt); if (n > 0) return n; System.out.println("Enter a positive number."); } }
    private int readNonNegativeInt(String prompt) { while (true) { int n = readInt(prompt); if (n >= 0) return n; System.out.println("Enter 0 or more."); } }
    private double readPositiveDouble(String prompt) { while (true) { double n = readDouble(prompt); if (n > 0) return n; System.out.println("Enter a positive amount."); } }
    private int readInt(String prompt) { while (true) { try { return Integer.parseInt(readText(prompt)); } catch (Exception e) { System.out.println("Enter a valid integer."); } } }
    private double readDouble(String prompt) { while (true) { try { return Double.parseDouble(readText(prompt)); } catch (Exception e) { System.out.println("Enter a valid number."); } } }
    private int parseInt(String s, int fallback) { try { return Integer.parseInt(s); } catch (Exception e) { return fallback; } }
    private double parseDouble(String s, double fallback) { try { return Double.parseDouble(s); } catch (Exception e) { return fallback; } }
    private boolean validDate(String s) { try { LocalDate.parse(s); return true; } catch (DateTimeParseException e) { System.out.println("Invalid date. Use YYYY-MM-DD."); return false; } }
    private String readDate(String prompt) { while (true) { String s = readText(prompt); if (validDate(s)) return s; } }
}

public class Supplier {
    private String supplierId;
    private String supplierName;
    private String phone;
    private String address;

    public Supplier() {}

    public Supplier(String supplierId, String supplierName, String phone, String address) {
        this.supplierId = supplierId;
        this.supplierName = supplierName;
        this.phone = phone;
        this.address = address;
    }

    public String getSupplierId() { return supplierId; }
    public String getSupplierName() { return supplierName; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
    public void setSupplierName(String value) { supplierName = value; }
    public void setPhone(String value) { phone = value; }
    public void setAddress(String value) { address = value; }

    public void displaySupplier() {
        System.out.println("--------------------------------------------");
        System.out.println("Supplier ID   : " + supplierId);
        System.out.println("Supplier Name : " + supplierName);
        System.out.println("Phone         : " + phone);
        System.out.println("Address       : " + address);
        System.out.println("--------------------------------------------");
    }

    public String toString() {
        return FileManager.clean(supplierId) + "|" + FileManager.clean(supplierName) + "|" +
                FileManager.clean(phone) + "|" + FileManager.clean(address);
    }
}

public class Purchase {
    private String purchaseId;
    private String medicineId;
    private String supplierId;
    private int quantity;
    private double price;
    private String date;

    public Purchase(String purchaseId, String medicineId, String supplierId,
                    int quantity, double price, String date) {
        this.purchaseId = purchaseId;
        this.medicineId = medicineId;
        this.supplierId = supplierId;
        this.quantity = quantity;
        this.price = price;
        this.date = date;
    }

    public String getPurchaseId() { return purchaseId; }
    public String getMedicineId() { return medicineId; }
    public String getSupplierId() { return supplierId; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
    public String getDate() { return date; }
    public double getTotal() { return quantity * price; }

    public void displayPurchase() {
        System.out.println("--------------------------------------------");
        System.out.println("Purchase ID : " + purchaseId);
        System.out.println("Medicine ID : " + medicineId);
        System.out.println("Supplier ID : " + supplierId);
        System.out.println("Quantity    : " + quantity);
        System.out.printf("Price       : Rs. %.2f%n", price);
        System.out.printf("Total       : Rs. %.2f%n", getTotal());
        System.out.println("Date        : " + date);
        System.out.println("--------------------------------------------");
    }

    public String toString() {
        return FileManager.clean(purchaseId) + "|" + FileManager.clean(medicineId) + "|" +
                FileManager.clean(supplierId) + "|" + quantity + "|" + price + "|" + FileManager.clean(date);
    }
}

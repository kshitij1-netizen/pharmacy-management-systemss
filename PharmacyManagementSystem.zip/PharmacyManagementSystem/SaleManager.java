import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class SaleManager {
    private ArrayList<Sale> sales;
    private Scanner scanner;
    private MedicineManager medicineManager;

    public SaleManager(Scanner scanner, MedicineManager medicineManager) {
        this.scanner = scanner;
        this.medicineManager = medicineManager;
        FileManager.createFiles();
        sales = FileManager.loadSales();
    }

    public ArrayList<Sale> getSales() { return sales; }

    public void addSale() {
        System.out.println("\n===== NEW SALE =====");
        String id = text("Sale ID: ");
        if (findSaleById(id) != null) { System.out.println("Sale ID already exists."); return; }
        Medicine medicine = medicineManager.findMedicineById(text("Medicine ID: "));
        if (medicine == null) { System.out.println("Medicine not found."); return; }
        if (medicine.isExpired()) { System.out.println("This medicine is expired and cannot be sold."); return; }
        int quantity = positiveInt("Quantity: ");
        if (quantity > medicine.getQuantity()) { System.out.println("Not enough stock."); return; }
        double price = medicine.getSellingPrice();
        String date = text("Date (YYYY-MM-DD, blank=today): ");
        if (date.isEmpty()) date = LocalDate.now().toString();
        Sale sale = new Sale(id, medicine.getMedicineId(), quantity, price, date);
        sales.add(sale);
        medicine.reduceStock(quantity);
        FileManager.saveSales(sales);
        FileManager.saveMedicines(medicineManager.getMedicines());
        System.out.printf("Sale saved. Total: Rs. %.2f%n", sale.getTotal());
        System.out.println("Remaining stock: " + medicine.getQuantity());
    }

    public void viewSales() {
        System.out.println("\n===== SALES LIST =====");
        if (sales.isEmpty()) { System.out.println("No sales found."); return; }
        for (Sale s : sales) s.displaySale();
    }

    public void salesHistory() {
        viewSales();
        System.out.printf("Total Sales Amount: Rs. %.2f%n", getTotalSalesAmount());
    }

    public void searchSale() {
        String key = text("Enter sale ID or medicine ID: ").toLowerCase();
        boolean found = false;
        for (Sale s : sales) if (s.getSaleId().toLowerCase().contains(key) || s.getMedicineId().toLowerCase().contains(key)) { s.displaySale(); found = true; }
        if (!found) System.out.println("Sale not found.");
    }

    public double getTotalSalesAmount() {
        double total = 0;
        for (Sale s : sales) total += s.getTotal();
        return total;
    }

    public Sale findSaleById(String id) {
        for (Sale s : sales) if (s.getSaleId().equalsIgnoreCase(id)) return s;
        return null;
    }

    private String text(String prompt) { System.out.print(prompt); return scanner.nextLine().trim(); }
    private int positiveInt(String prompt) { while (true) { try { int n = Integer.parseInt(text(prompt)); if (n > 0) return n; } catch (Exception ignored) {} System.out.println("Enter a positive integer."); } }
}

PHARMACY MANAGEMENT SYSTEM - JAVA CONSOLE PROJECT

How to run:
1. Open this folder in IntelliJ IDEA, Eclipse, VS Code, or a terminal.
2. Compile all Java files:
   javac *.java
3. Run:
   java Main

The program automatically creates these files for basic file handling:
- medicines.txt
- categories.txt
- suppliers.txt
- purchases.txt
- sales.txt

Date format: YYYY-MM-DD

Main features:
- Medicine management
- Category management
- Supplier management
- Purchase management
- Sales management
- Automatic stock updates
- Expiry checking
- Medicine search
- Billing and discount calculation
- Stock, expiry, sales and purchase reports

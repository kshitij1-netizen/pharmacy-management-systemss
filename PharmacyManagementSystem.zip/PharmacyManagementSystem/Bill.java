import java.util.ArrayList;

public class Bill {
    private String billId;
    private double subtotal;
    private double discount;
    private double total;
    private ArrayList<String> items;

    public Bill(String billId, double subtotal, double discount) {
        this.billId = billId;
        this.subtotal = subtotal;
        this.discount = discount;
        this.total = subtotal - discount;
        this.items = new ArrayList<String>();
    }

    public void addItem(String item) { items.add(item); }
    public double getTotal() { return total; }
    public double getSubtotal() { return subtotal; }
    public double getDiscount() { return discount; }

    public void displayBill() {
        System.out.println();
        System.out.println("============================================");
        System.out.println("              PHARMACY BILL");
        System.out.println("============================================");
        System.out.println("Bill ID : " + billId);
        if (!items.isEmpty()) {
            System.out.println("Items:");
            for (String item : items) System.out.println("- " + item);
        }
        System.out.printf("Subtotal : Rs. %.2f%n", subtotal);
        System.out.printf("Discount : Rs. %.2f%n", discount);
        System.out.printf("TOTAL    : Rs. %.2f%n", total);
        System.out.println("============================================");
    }
}

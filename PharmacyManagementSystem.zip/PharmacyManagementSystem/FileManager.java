import java.io.*;
import java.util.ArrayList;

public class FileManager {
    private static final String MEDICINE_FILE = "medicines.txt";
    private static final String CATEGORY_FILE = "categories.txt";
    private static final String SUPPLIER_FILE = "suppliers.txt";
    private static final String PURCHASE_FILE = "purchases.txt";
    private static final String SALE_FILE = "sales.txt";

    public static String clean(String value) {
        if (value == null) return "";
        return value.replace("|", "/").replace("\n", " ").replace("\r", " ");
    }

    private static void writeLines(String fileName, ArrayList<String> lines) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        }
    }

    private static ArrayList<String> readLines(String fileName) {
        ArrayList<String> lines = new ArrayList<String>();
        File file = new File(fileName);
        if (!file.exists()) return lines;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) lines.add(line);
            }
        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        }
        return lines;
    }

    public static void createFiles() {
        createFile(MEDICINE_FILE);
        createFile(CATEGORY_FILE);
        createFile(SUPPLIER_FILE);
        createFile(PURCHASE_FILE);
        createFile(SALE_FILE);
    }

    private static void createFile(String name) {
        File file = new File(name);
        if (!file.exists()) {
            try { file.createNewFile(); }
            catch (IOException e) { System.out.println("Cannot create " + name); }
        }
    }

    public static void saveMedicines(ArrayList<Medicine> list) {
        ArrayList<String> lines = new ArrayList<String>();
        for (Medicine m : list) lines.add(m.toString());
        writeLines(MEDICINE_FILE, lines);
    }

    public static ArrayList<Medicine> loadMedicines() {
        ArrayList<Medicine> list = new ArrayList<Medicine>();
        for (String line : readLines(MEDICINE_FILE)) {
            try {
                String[] d = line.split("\\|", -1);
                if (d.length != 11) continue;
                list.add(new Medicine(d[0], d[1], d[2], d[3], d[4],
                        Double.parseDouble(d[5]), Double.parseDouble(d[6]), Integer.parseInt(d[7]),
                        d[8], d[9], Integer.parseInt(d[10])));
            } catch (Exception ignored) {}
        }
        return list;
    }

    public static void saveCategories(ArrayList<Category> list) {
        ArrayList<String> lines = new ArrayList<String>();
        for (Category c : list) lines.add(c.toString());
        writeLines(CATEGORY_FILE, lines);
    }

    public static ArrayList<Category> loadCategories() {
        ArrayList<Category> list = new ArrayList<Category>();
        for (String line : readLines(CATEGORY_FILE)) {
            String[] d = line.split("\\|", -1);
            if (d.length == 3) list.add(new Category(d[0], d[1], d[2]));
        }
        return list;
    }

    public static void saveSuppliers(ArrayList<Supplier> list) {
        ArrayList<String> lines = new ArrayList<String>();
        for (Supplier s : list) lines.add(s.toString());
        writeLines(SUPPLIER_FILE, lines);
    }

    public static ArrayList<Supplier> loadSuppliers() {
        ArrayList<Supplier> list = new ArrayList<Supplier>();
        for (String line : readLines(SUPPLIER_FILE)) {
            String[] d = line.split("\\|", -1);
            if (d.length == 4) list.add(new Supplier(d[0], d[1], d[2], d[3]));
        }
        return list;
    }

    public static void savePurchases(ArrayList<Purchase> list) {
        ArrayList<String> lines = new ArrayList<String>();
        for (Purchase p : list) lines.add(p.toString());
        writeLines(PURCHASE_FILE, lines);
    }

    public static ArrayList<Purchase> loadPurchases() {
        ArrayList<Purchase> list = new ArrayList<Purchase>();
        for (String line : readLines(PURCHASE_FILE)) {
            try {
                String[] d = line.split("\\|", -1);
                if (d.length == 6) list.add(new Purchase(d[0], d[1], d[2], Integer.parseInt(d[3]), Double.parseDouble(d[4]), d[5]));
            } catch (Exception ignored) {}
        }
        return list;
    }

    public static void saveSales(ArrayList<Sale> list) {
        ArrayList<String> lines = new ArrayList<String>();
        for (Sale s : list) lines.add(s.toString());
        writeLines(SALE_FILE, lines);
    }

    public static ArrayList<Sale> loadSales() {
        ArrayList<Sale> list = new ArrayList<Sale>();
        for (String line : readLines(SALE_FILE)) {
            try {
                String[] d = line.split("\\|", -1);
                if (d.length == 5) list.add(new Sale(d[0], d[1], Integer.parseInt(d[2]), Double.parseDouble(d[3]), d[4]));
            } catch (Exception ignored) {}
        }
        return list;
    }
}

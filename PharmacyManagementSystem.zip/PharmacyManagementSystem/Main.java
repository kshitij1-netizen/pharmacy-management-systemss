import java.util.Scanner;

public class Main {
    static Scanner scanner = new Scanner(System.in);
    static MedicineManager medicineManager = new MedicineManager(scanner);
    static CategoryManager categoryManager = new CategoryManager(scanner);
    static SupplierManager supplierManager = new SupplierManager(scanner);
    static PurchaseManager purchaseManager = new PurchaseManager(scanner, medicineManager, supplierManager);
    static SaleManager saleManager = new SaleManager(scanner, medicineManager);
    static BillingManager billingManager = new BillingManager(scanner, medicineManager);
    static ReportManager reportManager = new ReportManager(medicineManager, purchaseManager, saleManager);

    public static void main(String[] args) {
        int choice;
        do {
            displayMainMenu();
            choice = integer("Enter your choice: ");
            switch (choice) {
                case 1: medicineMenu(); break;
                case 2: categoryMenu(); break;
                case 3: supplierMenu(); break;
                case 4: purchaseMenu(); break;
                case 5: salesMenu(); break;
                case 6: stockMenu(); break;
                case 7: expiryMenu(); break;
                case 8: searchMenu(); break;
                case 9: billingMenu(); break;
                case 10: reportMenu(); break;
                case 11: System.out.println("Thank you for using Pharmacy Management System!"); break;
                default: System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 11);
        scanner.close();
    }

    static void displayMainMenu() {
        System.out.println();
        System.out.println("============================================");
        System.out.println("       PHARMACY MANAGEMENT SYSTEM");
        System.out.println("============================================");
        System.out.println("1. Medicine Management");
        System.out.println("2. Category Management");
        System.out.println("3. Supplier Management");
        System.out.println("4. Purchase Management");
        System.out.println("5. Sales Management");
        System.out.println("6. Stock Management");
        System.out.println("7. Expiry Management");
        System.out.println("8. Search Medicine");
        System.out.println("9. Billing");
        System.out.println("10. Reports");
        System.out.println("11. Exit");
        System.out.println("============================================");
    }

    static void medicineMenu() {
        int choice;
        do {
            System.out.println("\n===== MEDICINE MANAGEMENT =====");
            System.out.println("1. Add Medicine");
            System.out.println("2. View Medicines");
            System.out.println("3. Search by ID");
            System.out.println("4. Search by Name");
            System.out.println("5. Search by Category");
            System.out.println("6. Update Medicine");
            System.out.println("7. Delete Medicine");
            System.out.println("8. Low Stock Medicines");
            System.out.println("9. Back");
            choice = integer("Choice: ");
            switch (choice) {
                case 1: medicineManager.addMedicine(); break;
                case 2: medicineManager.viewMedicines(); break;
                case 3: medicineManager.searchById(); break;
                case 4: medicineManager.searchByName(); break;
                case 5: medicineManager.searchByCategory(); break;
                case 6: medicineManager.updateMedicine(); break;
                case 7: medicineManager.deleteMedicine(); break;
                case 8: medicineManager.showLowStock(); break;
                case 9: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 9);
    }

    static void categoryMenu() {
        int choice;
        do {
            System.out.println("\n===== CATEGORY MANAGEMENT =====");
            System.out.println("1. Add Category\n2. View Categories\n3. Search by ID\n4. Search by Name\n5. Update\n6. Delete\n7. Back");
            choice = integer("Choice: ");
            switch (choice) {
                case 1: categoryManager.addCategory(); break;
                case 2: categoryManager.viewCategories(); break;
                case 3: categoryManager.searchCategoryById(); break;
                case 4: categoryManager.searchCategoryByName(); break;
                case 5: categoryManager.updateCategory(); break;
                case 6: categoryManager.deleteCategory(); break;
                case 7: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 7);
    }

    static void supplierMenu() {
        int choice;
        do {
            System.out.println("\n===== SUPPLIER MANAGEMENT =====");
            System.out.println("1. Add Supplier\n2. View Suppliers\n3. Search Supplier\n4. Update Supplier\n5. Delete Supplier\n6. Back");
            choice = integer("Choice: ");
            switch (choice) {
                case 1: supplierManager.addSupplier(); break;
                case 2: supplierManager.viewSuppliers(); break;
                case 3: supplierManager.searchSupplier(); break;
                case 4: supplierManager.updateSupplier(); break;
                case 5: supplierManager.deleteSupplier(); break;
                case 6: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 6);
    }

    static void purchaseMenu() {
        int choice;
        do {
            System.out.println("\n===== PURCHASE MANAGEMENT =====");
            System.out.println("1. Add Purchase\n2. View Purchases\n3. Purchase History\n4. Search Purchase\n5. Back");
            choice = integer("Choice: ");
            switch (choice) {
                case 1: purchaseManager.addPurchase(); break;
                case 2: purchaseManager.viewPurchases(); break;
                case 3: purchaseManager.purchaseHistory(); break;
                case 4: purchaseManager.searchPurchase(); break;
                case 5: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 5);
    }

    static void salesMenu() {
        int choice;
        do {
            System.out.println("\n===== SALES MANAGEMENT =====");
            System.out.println("1. New Sale\n2. View Sales\n3. Sales History\n4. Search Sale\n5. Back");
            choice = integer("Choice: ");
            switch (choice) {
                case 1: saleManager.addSale(); break;
                case 2: saleManager.viewSales(); break;
                case 3: saleManager.salesHistory(); break;
                case 4: saleManager.searchSale(); break;
                case 5: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 5);
    }

    static void stockMenu() {
        int choice;
        do {
            System.out.println("\n===== STOCK MANAGEMENT =====");
            System.out.println("1. View Stock\n2. Add Stock\n3. Reduce Stock\n4. Low Stock\n5. Back");
            choice = integer("Choice: ");
            switch (choice) {
                case 1: medicineManager.viewMedicines(); break;
                case 2: medicineManager.addStock(); break;
                case 3: medicineManager.reduceStock(); break;
                case 4: medicineManager.showLowStock(); break;
                case 5: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 5);
    }

    static void expiryMenu() {
        int choice;
        do {
            System.out.println("\n===== EXPIRY MANAGEMENT =====");
            System.out.println("1. View Expiry Dates\n2. Show Expired Medicines\n3. Back");
            choice = integer("Choice: ");
            switch (choice) {
                case 1: medicineManager.showExpiryDates(); break;
                case 2: medicineManager.showExpiredMedicines(); break;
                case 3: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 3);
    }

    static void searchMenu() {
        int choice;
        do {
            System.out.println("\n===== SEARCH MEDICINE =====");
            System.out.println("1. Search by ID\n2. Search by Name\n3. Search by Category\n4. Back");
            choice = integer("Choice: ");
            switch (choice) {
                case 1: medicineManager.searchById(); break;
                case 2: medicineManager.searchByName(); break;
                case 3: medicineManager.searchByCategory(); break;
                case 4: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 4);
    }

    static void billingMenu() {
        int choice;
        do {
            System.out.println("\n===== BILLING =====");
            System.out.println("1. Create New Bill\n2. Calculate Total\n3. Apply Discount\n4. Back");
            choice = integer("Choice: ");
            switch (choice) {
                case 1: billingManager.createBill(); break;
                case 2: billingManager.calculateTotal(); break;
                case 3: billingManager.applyDiscount(); break;
                case 4: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 4);
    }

    static void reportMenu() {
        int choice;
        do {
            System.out.println("\n===== REPORTS =====");
            System.out.println("1. Stock Report");
            System.out.println("2. Low Stock Report");
            System.out.println("3. Expiry Report");
            System.out.println("4. Sales and Purchase Report");
            System.out.println("5. Category Report");
            System.out.println("6. Supplier Report");
            System.out.println("7. Summary Report");
            System.out.println("8. Back");
            choice = integer("Choice: ");
            switch (choice) {
                case 1: reportManager.stockReport(); break;
                case 2: reportManager.lowStockReport(); break;
                case 3: reportManager.expiryReport(); break;
                case 4: reportManager.salesPurchaseReport(); break;
                case 5: reportManager.categoryReport(); break;
                case 6: reportManager.supplierReport(); break;
                case 7: reportManager.summaryReport(); break;
                case 8: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 8);
    }

    static int integer(String prompt) {
        while (true) {
            System.out.print(prompt);
            try { return Integer.parseInt(scanner.nextLine().trim()); }
            catch (Exception e) { System.out.println("Please enter a valid number."); }
        }
    }
}

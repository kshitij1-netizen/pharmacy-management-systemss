import java.util.ArrayList;
import java.util.Scanner;

public class SupplierManager {
    private ArrayList<Supplier> suppliers;
    private Scanner scanner;

    public SupplierManager(Scanner scanner) {
        this.scanner = scanner;
        FileManager.createFiles();
        suppliers = FileManager.loadSuppliers();
    }

    public ArrayList<Supplier> getSuppliers() { return suppliers; }

    public void addSupplier() {
        System.out.println("\n===== ADD SUPPLIER =====");
        String id = text("Supplier ID: ");
        if (findSupplierById(id) != null) { System.out.println("ID already exists."); return; }
        String name = text("Supplier Name: ");
        String phone = text("Phone: ");
        String address = text("Address: ");
        suppliers.add(new Supplier(id, name, phone, address));
        FileManager.saveSuppliers(suppliers);
        System.out.println("Supplier added successfully.");
    }

    public void viewSuppliers() {
        System.out.println("\n===== SUPPLIERS =====");
        if (suppliers.isEmpty()) { System.out.println("No suppliers found."); return; }
        for (Supplier s : suppliers) s.displaySupplier();
    }

    public void searchSupplier() {
        String key = text("Enter supplier ID or name: ").toLowerCase();
        boolean found = false;
        for (Supplier s : suppliers) {
            if (s.getSupplierId().toLowerCase().contains(key) || s.getSupplierName().toLowerCase().contains(key)) {
                s.displaySupplier(); found = true;
            }
        }
        if (!found) System.out.println("Supplier not found.");
    }

    public void updateSupplier() {
        Supplier s = findSupplierById(text("Supplier ID: "));
        if (s == null) { System.out.println("Supplier not found."); return; }
        String name = text("New name: ");
        String phone = text("New phone: ");
        String address = text("New address: ");
        if (!name.isEmpty()) s.setSupplierName(name);
        if (!phone.isEmpty()) s.setPhone(phone);
        if (!address.isEmpty()) s.setAddress(address);
        FileManager.saveSuppliers(suppliers);
        System.out.println("Supplier updated.");
    }

    public void deleteSupplier() {
        Supplier s = findSupplierById(text("Supplier ID: "));
        if (s == null) { System.out.println("Supplier not found."); return; }
        if (text("Type YES to delete: ").equalsIgnoreCase("YES")) { suppliers.remove(s); FileManager.saveSuppliers(suppliers); System.out.println("Supplier deleted."); }
        else System.out.println("Delete cancelled.");
    }

    public Supplier findSupplierById(String id) {
        for (Supplier s : suppliers) if (s.getSupplierId().equalsIgnoreCase(id)) return s;
        return null;
    }

    private String text(String prompt) { System.out.print(prompt); return scanner.nextLine().trim(); }
}

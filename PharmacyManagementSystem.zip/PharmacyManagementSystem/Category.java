public class Category {
    private String categoryId;
    private String categoryName;
    private String description;

    public Category() {}

    public Category(String categoryId, String categoryName, String description) {
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.description = description;
    }

    public String getCategoryId() { return categoryId; }
    public String getCategoryName() { return categoryName; }
    public String getDescription() { return description; }
    public void setCategoryName(String value) { categoryName = value; }
    public void setDescription(String value) { description = value; }

    public void displayCategory() {
        System.out.println("--------------------------------------------");
        System.out.println("Category ID   : " + categoryId);
        System.out.println("Category Name : " + categoryName);
        System.out.println("Description   : " + description);
        System.out.println("--------------------------------------------");
    }

    public String toString() {
        return FileManager.clean(categoryId) + "|" + FileManager.clean(categoryName) + "|" + FileManager.clean(description);
    }
}

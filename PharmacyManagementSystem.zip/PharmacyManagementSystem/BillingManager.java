import java.util.ArrayList;
import java.util.Scanner;

public class BillingManager {
    private Scanner scanner;
    private MedicineManager medicineManager;

    public BillingManager(Scanner scanner, MedicineManager medicineManager) {
        this.scanner = scanner;
        this.medicineManager = medicineManager;
    }

    public void createBill() {
        System.out.println("\n===== CREATE BILL =====");
        String billId = text("Bill ID: ");
        ArrayList<String> items = new ArrayList<String>();
        double subtotal = 0;
        while (true) {
            String id = text("Medicine ID (blank to finish): ");
            if (id.isEmpty()) break;
            Medicine medicine = medicineManager.findMedicineById(id);
            if (medicine == null) { System.out.println("Medicine not found."); continue; }
            if (medicine.isExpired()) { System.out.println("Expired medicine cannot be billed."); continue; }
            int quantity = positiveInt("Quantity: ");
            if (quantity > medicine.getQuantity()) { System.out.println("Not enough stock."); continue; }
            double lineTotal = quantity * medicine.getSellingPrice();
            subtotal += lineTotal;
            items.add(medicine.getMedicineName() + " x " + quantity + " = Rs. " + String.format("%.2f", lineTotal));
        }
        if (items.isEmpty()) { System.out.println("No items added."); return; }
        double percentage = nonNegativeDouble("Discount %: ");
        if (percentage > 100) percentage = 100;
        double discount = subtotal * percentage / 100.0;
        Bill bill = new Bill(billId, subtotal, discount);
        for (String item : items) bill.addItem(item);
        bill.displayBill();
    }

    public void calculateTotal() {
        System.out.println("\n===== CALCULATE TOTAL =====");
        double subtotal = nonNegativeDouble("Subtotal: ");
        double discount = nonNegativeDouble("Discount amount: ");
        if (discount > subtotal) { System.out.println("Discount cannot exceed subtotal."); return; }
        System.out.printf("Final Total: Rs. %.2f%n", subtotal - discount);
    }

    public void applyDiscount() {
        System.out.println("\n===== APPLY DISCOUNT =====");
        double amount = nonNegativeDouble("Amount: ");
        double percentage = nonNegativeDouble("Discount percentage: ");
        if (percentage > 100) { System.out.println("Percentage cannot exceed 100."); return; }
        double discount = amount * percentage / 100;
        System.out.printf("Discount Amount: Rs. %.2f%n", discount);
        System.out.printf("Final Total: Rs. %.2f%n", amount - discount);
    }

    private String text(String prompt) { System.out.print(prompt); return scanner.nextLine().trim(); }
    private int positiveInt(String prompt) { while (true) { try { int n = Integer.parseInt(text(prompt)); if (n > 0) return n; } catch (Exception ignored) {} System.out.println("Enter a positive integer."); } }
    private double nonNegativeDouble(String prompt) { while (true) { try { double n = Double.parseDouble(text(prompt)); if (n >= 0) return n; } catch (Exception ignored) {} System.out.println("Enter 0 or more."); } }
}
